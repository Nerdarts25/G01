% filme('T�tulo', [G�neros], Ano, Diretor, [Atores], Nota,classifica��o)

filme('Mad Max: Estrada da Furia', [acao], 2015, 'George Miller', ['Tom Hardy', 'Charlize Theron'], 8.1, 16).
filme('Velozes e Furiosos 7', [acao], 2015, 'James Wan', ['Vin Diesel', 'Paul Walker'], 7.9, 14).
filme('Missao Impossivel: Fallout', [acao], 2018, 'Christopher McQuarrie', ['Tom Cruise', 'Henry Cavill'], 8.0, 14).
filme('O Protetor: The Equalizer', [acao], 2014, 'Antoine Fuqua', ['Denzel Washington'], 7.7, 18).
filme('Como eu era antes de voc�', [romance], 2016, 'Thea Sharrock', ['Emilia Clarke', 'Sam Claflin'], 7.4, 12).
filme('Diario de uma paix�o', [romance], 2004, 'Nick Cassavetes', ['Ryan Gosling', 'Rachel McAdams'], 7.8, 12).
filme('Simplesmente Acontece', [romance], 2014, 'Christian Ditter', ['Lily Collins', 'Sam Claflin'], 7.2, 12).
filme('A culpa � das estrelas', [romance], 2014, 'Josh Boone', ['Shailene Woodley', 'Ansel Elgort'], 7.7, 12).
filme('O Exorcista', [terror], 1973, 'William Friedkin', ['Ellen Burstyn', 'Max Von Sydow', 'Linda Blair'], 8.1, 18).
filme('A Bruxa', [terror], 2015, 'Robert Eggers', ['Anya Taylor-Joy', 'Ralph Ineson', 'Kate Dickie'], 6.9, 16).
filme('Run', [terror], 2017, 'Aneesh Chaganty', ['Sarah Paulson', 'Kiera Allen'], 6.7, 14).
filme('Heredit�rio', [terror], 2018, 'Ari Aster', ['Toni Collette', 'Gabriel Byrne', 'Alex Wolff'], 7.3, 16).
filme('Toy Story', [animacao], 1995, 'John Lasseter', ['Tom Hanks', 'Tim Allen'], 8.0, livre).
filme('O Rei Le�o', [animacao], 1994, 'Roger Allers e Rob Minkoff', ['Matthew Broderick', 'Jeremy Irons', 'James Earl Jones'], 8.5, livre).
filme('A Viagem de Chihiro', [animacao], 2001, 'Hayao Miyazaki', ['Rumi Hiiragi', 'Miyu Irino'], 8.6, 10).
filme('Divertidamente', [animacao], 2015, 'Pete Docter e Ronnie Del Carmen', ['Amy Poehler', 'Phyllis Smith'], 8.2, 10).

% Fatos de usu�rios
usuario('gissanio', 20, [acao], ['George Miller'], ['Tom Hardy']).
usuario('flora', 21, [romance], ['Christian Ditter'], ['Sam Claflin']).
usuario('filomena', 18, [terror], ['Ari Aster'], ['Toni Collette']).
usuario('joana', 17, [terror], ['Jordan Peele'], ['Daniel Kaluuya']).
usuario('mario', 24, [acao], ['Chad Stahelski'], ['Keanu Reeves']).
usuario('leila', 22, [romance], ['Thea Sharrock'], ['Sam Claflin']).
usuario('valter', 19, [ficcao], ['Christopher Nolan'], ['Leonardo DiCaprio']).
usuario('helena', 28, [suspense], ['Ari Aster'], ['Toni Collette']).
usuario('igor', 21, [acao], ['George Miller'], ['Tom Hardy']).

% Intersec��o de listas (g�neros, diretores ou atores)
tem_intersecao([H|_], L2) :- member(H, L2), !.
tem_intersecao([_|T], L2) :- tem_intersecao(T, L2).

% Regras de recomenda��o
recomendar_filme(Nome, Titulo) :-
    usuario(Nome, Idade, Generos, Diretores, Atores),
    filme(Titulo, GenerosF, _, Diretor, AtoresF, _, Classificacao),
    Classificacao =< Idade,
    (tem_intersecao(Generos, GenerosF);
     member(Diretor, Diretores);
     tem_intersecao(Atores, AtoresF)).

recomendar_filme(Nome, Titulo) :-
    usuario(Nome, Idade, Generos, Diretores, Atores),
    filme(Titulo, GenerosF, _, Diretor, AtoresF, Nota, Classificacao),
    Classificacao =< Idade,
    Nota >= 7.0,
    (tem_intersecao(Generos, GenerosF);
     member(Diretor, Diretores);
     tem_intersecao(Atores, AtoresF)).

% Interface de sugest�o
sugerir(Nome) :-
    write('Sugest�es de filmes para '), write(Nome), write(':'), nl,
    recomendar_filme(Nome, Filme),
    write('- '), write(Filme), nl,
    fail.
sugerir(_) :- !.












































